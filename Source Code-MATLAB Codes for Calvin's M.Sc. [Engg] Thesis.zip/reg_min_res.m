[foo]=reg_min_res(J,recon_mesh,foo_prev,data_diff,alpha)
if it == 1
    foo = recon_mesh.mua*1/10;
  else
      foo = foo_prev;
  end
  
  
  r = J*foo - data_diff;
  %eps = norm(r,2)*5/100;
  eps = 0.00001;
  rprev = r +2;
  itt = 1;
  err_pj = 20;
  alpha =50;
  while err_pj >eps
      rn_p = norm(rprev,2);
      ln = J'*r + alpha*foo;
      gn = J*ln;
      %hn = J'*gn;
      %kn = norm(gn,2)^2/norm(hn,2)^2;
      kn = norm(ln,2)^2/(norm(gn,2)^2 + alpha *norm(ln,2)^2);%kn = norm(ln,2)^2/norm(gn,2)^2;
      foo = foo - kn*ln;
      rprev =r;
       r = J*foo - data_diff;
       rn = norm(r,2);
     err_pj = ((rn_p - rn)/(rn_p))*100;
       itt = itt +1;
       %figure; plotimage(fwd_mesh, fwd_mesh.mua +foo);
  end