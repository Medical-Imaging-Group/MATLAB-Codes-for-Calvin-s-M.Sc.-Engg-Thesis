%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%% PICCS Dynamic DOT with a stationary blob     %%%
%%% (patient_mesh)                               %%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
close all;
clear all;

% frames=8;%number of frames
mua=0.02;%initial mua
x=-28;%specify the blob position
y=7;
%  mesh_name='circle_1933_86';%name of the mesh to be loaded
 %mesh_name='pat509';
 mesh_name='pat509';
mesh=load_mesh('pat509_refine');
 ind=find(mesh.region==2);
mesh.mua(ind)=0.015;
save_mesh(mesh, 'mesh_r0_r1');
calib_mesh_name='mesh_r0_r1';


mesh1=load_mesh(mesh_name);
 ind=find(mesh1.region==2);
mesh1.mua(ind)=0.015;
save_mesh(mesh1, 'mesh_r0_r1_1');
 
mesh_name='mesh_r0_r1_1';
 
% mesh_name='pat1914_2';

%%%%%%%%%%%
%%%for profile plot%%%%
mesh = load_mesh(mesh_name);
blob.x =x;
blob.y  =y;
blob.r =8;
blob.mua =mua;
blob.mus = 1.0;
blob.ri = 1.33;
blob.region =3;
meshb = add_blob_stnd(mesh, blob);
save_mesh(meshb, 'mesh_blob1_coarse');
 figure,plotimage(meshb,meshb.mua);
%%%%%%%%%%%%%%%%%%%%%%%

mesh = load_mesh(calib_mesh_name);
blob.x =x;
blob.y  =y;
blob.r =8;
blob.mua =mua;
blob.mus = 1.0;
blob.ri = 1.33;
blob.region =3;
meshb = add_blob_stnd(mesh, blob);
save_mesh(meshb, 'mesh_blob1');
 figure,plotimage(meshb,meshb.mua);
data_1 = femdata('mesh_blob1', 0);
mysave('mesh_blob1.paa', data_1.paa);
add_noise('mesh_blob1.paa', 1, 0, 'mesh_blob1_Noise.paa') % 1% noise to the data

%%%Calibration

% [data1, mesh] = femdata(mesh,0);
% save_data(data1,'mesh_data.paa');
% 
% homog_data = load_data('mesh_data.paa');
% anom_data = load_data('mesh_blob1_Noise.paa'); %
% 
% mesh_homog = mesh_name;
% mesh_anom  = mesh_name;
% 
% frequency = 0;
% iteration = 5;
% 
% 
% [data,mesh] = calibrate_stnd(homog_data,...
%                    anom_data,...
%                    mesh_homog,...
%                    mesh_anom,...
%         		   frequency,...
%         		   iteration);
%                
%                
% save_data(data,'circle_stnd_calibrated_data.paa');

%%%%%%%%%%%%%







%Reconstruction of first frame using non-linear method%
tic;
% fwd_mesh=meshb;
       fwd_mesh =mesh_name;
%      fwd_mesh =mesh_name;
recon_basis =[50 50];
data_fn_1 = 'mesh_blob1_Noise.paa';
iteration =1;
output_fn = ['recon_dynamic_l2', num2str(recon_basis(1))];
filter_n =0;
lambda=5;
[fwd_mesh,pj_error] = reconstruct_stnd_cw_first_frame(fwd_mesh,...
    recon_basis,...
    data_fn_1,...
    iteration,...
    lambda,...
    'sol_l2_fn',...
    filter_n)
%  read_solution(fwd_mesh, output_fn);
figure,plotimage(fwd_mesh,fwd_mesh.mua)
save_mesh(fwd_mesh, 'fwd_mesh_l2');
toc;

%%%Laplacian Priors%%%%%%%%%%%
tic;
% fwd_mesh=meshb;
       fwd_mesh =mesh_name;
%      fwd_mesh =mesh_name;
recon_basis =[50 50];
data_fn_1 = 'mesh_blob1_Noise.paa';
iteration =20;
output_fn = ['recon_dynamic_l2', num2str(recon_basis(1))];
filter_n =0;
lambda=5;
[fwd_mesh,pj_error] = reconstruct_stnd_cw_spatial(fwd_mesh,...
    recon_basis,...
    data_fn_1,...
    iteration,...
    lambda,...
    'sol_l2_fn',...
    filter_n)
%  read_solution(fwd_mesh, output_fn);
figure,plotimage(fwd_mesh,fwd_mesh.mua)
save_mesh(fwd_mesh, 'fwd_mesh_l2');
toc;
%%%%%%%%%%%%%%%%%%%%%%%%%%%%



%%%for PICCS%%%%%%%%%
% fwd_mesh ='mesh_blob1';
fwd_mesh =mesh_name;
tic;
recon_basis =[50 50];
data_fn_1 = 'mesh_blob1_Noise.paa';
iteration =10;
output_fn = ['recon_dynamic_l2', num2str(recon_basis(1))];
filter_n =0;
lambda=5;
[fwd_mesh,pj_error] = reconstruct_stnd_cw_picL1(fwd_mesh,...
    recon_basis,...
    data_fn_1,...
    iteration,...
    lambda,...
    'sol_l1_fn',...
    filter_n,...
    fwd_mesh)
%  read_solution(fwd_mesh, output_fn);
figure,plotimage(fwd_mesh,fwd_mesh.mua)
save_mesh(fwd_mesh, 'fwd_mesh_l2');
toc;
%%%%%%%%%%%%%%%%%













% %%%%%%PICCS
% % fwd_mesh ='mesh_blob1';
% fwd_mesh ='mesh_r0_r1';
% % snapnow;
% tic;
% recon_basis =[50 50];
% data_fn_1 = 'mesh_blob1_Noise.paa';
% iteration =20;
% output_fn = ['recon_dynamic_l2', num2str(recon_basis(1))];
% filter_n =0;
% lambda=1;
% [fwd_mesh,pj_error] = reconstruct_stnd_cw_l2_stationary_piccs(fwd_mesh,...
%     recon_basis,...
%     data_fn_1,...
%     iteration,...
%     lambda,...
%     'sol_piccs_fn',...
%     filter_n,...
%     fwd_mesh)
% %  read_solution(fwd_mesh, output_fn);
% figure,plotimage(fwd_mesh,fwd_mesh.mua)
% save_mesh(fwd_mesh, 'fwd_mesh_l2');
% toc;
% 
% %%%%%%%%%%%%%



%%%Profile plot%%%%%%%

input_mesh = 'mesh_blob1_coarse';


mesh = load_mesh(input_mesh);
% max_ent = read_solution(mesh,'sol_piccs_fn');
max_l2=read_solution(mesh,'sol_l2_fn');
max_l3=read_solution(mesh,'sol_l1_fn');
format long;
%x = linspace(-42.95,42.95,400);
x = linspace(-42,42,400);
% y = -(10/20).*x;
 y = 6.*ones(1,length(x));
%y = linspace(-20,20,400);
z = y;


% % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % 
% xone = griddata(mesh.nodes(:,1),mesh.nodes(:,2),max_ent.mua,x,y);
xorg = griddata(mesh.nodes(:,1),mesh.nodes(:,2),mesh.mua,x,y);
xtwo = griddata(mesh.nodes(:,1),mesh.nodes(:,2),max_l2.mua,x,y);
xthree = griddata(mesh.nodes(:,1),mesh.nodes(:,2),max_l3.mua,x,y);
figure;
hold on
% subplot(1,3,1);
hold on
plot(x,xorg,'k-')
% plot(x,xone,'r--')
plot(x,xtwo,'b--')
plot(x,xthree,'g--')
legend('Target','Laplacian Prior','Prior Image with L1');
% plot(x,xin,'k')
% plot(x,xout,'k--')yyyyyyyyyyyyy
hold off