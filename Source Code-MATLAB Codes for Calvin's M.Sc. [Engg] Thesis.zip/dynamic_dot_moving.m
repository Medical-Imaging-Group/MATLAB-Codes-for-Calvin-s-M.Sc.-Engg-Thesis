%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%% Dynamic DOT with a moving blob               %%%
%%%                                              %%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
close all;
clear all;

frames=11;%number of frames
mua=0.02;%initial mua
% x=10;%specify the blob position
% y=0;
xcor=[20 20 16 12 8 4 0 -4 -8 -12 -16 -20];
ycor=[0 4 8 12 16 20 20 16 12 8 4 0];
    mesh_name='circle_1933_86';%name of the mesh to be loaded
% mesh_name='1914_2';
% mesh_name='504';
% mesh_name='pat1915_1';
 calib_mesh_name='circle_10249_86_16_2d';
% calib_mesh_name='1914';

mesh = load_mesh(calib_mesh_name);
blob.x =xcor(1);
blob.y  =ycor(1);
blob.r =10;
blob.mua =mua;
blob.mus = 1.0;
blob.ri = 1.33;
blob.region = 1;
meshb = add_blob_stnd(mesh, blob);
save_mesh(meshb, 'mesh_blob1');
data_1 = femdata('mesh_blob1', 0);
mysave('mesh_blob1.paa', data_1.paa);

add_noise('mesh_blob1.paa', 0, 0, 'mesh_blob1_Noise.paa') % 1% noise to the data


%calibration
[data1, mesh] = femdata(mesh,0);
save_data(data1,'mesh_data.paa');

homog_data = load_data('mesh_data.paa');
anom_data = load_data('mesh_blob1_Noise.paa'); %

mesh_homog = mesh_name;
mesh_anom  = mesh_name;

frequency = 0;
iteration = 5;


[data,mesh] = calibrate_stnd(homog_data,...
                   anom_data,...
                   mesh_homog,...
                   mesh_anom,...
        		   frequency,...
        		   iteration);
               
               
save_data(data,'circle_stnd_calibrated_data.paa');
% save_mesh(mesh,'circle_stnd_calibrated');



%Reconstruction of first frame using non-linear method%
fwd_mesh =mesh;
tic;
recon_basis =[60 60];
data_fn_1 = 'circle_stnd_calibrated_data.paa';
iteration =20;
output_fn = ['recon_dynamic_l2', num2str(recon_basis(1))];
filter_n =0;
lambda=35;
[fwd_mesh,pj_error] = reconstruct_stnd_cw_first_frame(fwd_mesh,...
    recon_basis,...
    data_fn_1,...
    iteration,...
    lambda,...
    output_fn,...
    filter_n)
%  read_solution(fwd_mesh, output_fn);
figure,plotimage(fwd_mesh,fwd_mesh.mua)
save_mesh(fwd_mesh, 'fwd_mesh_l2');
toc;


for i=1:frames
      mesh = load_mesh(mesh_name);
    
    blob.x =xcor(i);
    blob.y  =ycor(i);
    
    blob.r =10;
    blob.mua =mua;
    blob.mus = 1.0;
    blob.ri = 1.33;
    blob.region = 1;
    
    
   meshb = add_blob_stnd(mesh, blob);
save_mesh(meshb, 'mesh1_blob1');
data_1 = femdata('mesh1_blob1', 0);
mysave('mesh1_blob1.paa', data_1.paa);

add_noise('mesh1_blob1.paa', 1, 0, 'mesh1_blob1_Noise.paa') % 1% noise to the data


%calibration
[data1, mesh] = femdata(mesh,0);
save_data(data1,'mesh1_data.paa');

homog_data = load_data('mesh1_data.paa');
anom_data = load_data('mesh1_blob1_Noise.paa'); %

mesh_homog = mesh_name;
mesh_anom  = mesh_name;

frequency = 0;
iteration = 5;


[data_1,mesh] = calibrate_stnd(homog_data,...
                   anom_data,...
                   mesh_homog,...
                   mesh_anom,...
        		   frequency,...
        		   iteration);
               
               
save_data(data_1,'mesh1_blob1_calibrated_data.paa');
if i==1
    data_1_N=load_data('circle_stnd_calibrated_data.paa');
    data_1_N=data_1_N.paa;
    data_1_N=log(data_1_N(:,1));
else
    
    
    data_1_N=load_data('mesh1_blob1_calibrated_data.paa');
    data_1_N=data_1_N.paa;
    data_1_N=log(data_1_N(:,1));
end
%     mua=mua+0.01;%increase the mua value for the next frame
    
    
    data_1 = femdata('mesh_blob1', 0);
    %%%Next frame%%%%
    mesh = load_mesh(calib_mesh_name);
    blob.x =xcor(i+1);
    blob.y  =ycor(i+1);
    
    blob.r =10;
    blob.mua =mua;
    blob.mus = 1.0;
    blob.ri = 1.33;
    blob.region = 1;
    
    meshb = add_blob_stnd(mesh, blob);
save_mesh(meshb, 'mesh2_blob1');
data_1 = femdata('mesh2_blob1', 0);
mysave('mesh2_blob1.paa', data_1.paa);

add_noise('mesh2_blob1.paa', 1, 0, 'mesh2_blob1_Noise.paa') % 1% noise to the data


%calibration
[data1, mesh] = femdata(mesh,0);
save_data(data1,'mesh2_data.paa');

homog_data = load_data('mesh2_data.paa');
anom_data = load_data('mesh2_blob1_Noise.paa'); %

mesh_homog = mesh_name;
mesh_anom  = mesh_name;

frequency = 0;
iteration = 5;


[data_2,mesh] = calibrate_stnd(homog_data,...
                   anom_data,...
                   mesh_homog,...
                   mesh_anom,...
        		   frequency,...
        		   iteration);
               
               
save_data(data_2,'mesh2_blob1_calibrated_data.paa');
    data_2_N=load_data('mesh2_blob1_calibrated_data.paa');
    data_2_N=data_2_N.paa;
    data_2_N=log(data_2_N(:,1));
    diff_data_matrix(:,i)=data_2_N-data_1_N;
    close all;
end
save diff_data_matrix.mat diff_data_matrix

%%%%Reconstruction of frames %%%%%%%%%%%

%%%%l-1 reconstruction%%%%
for i=1:10
    if i==1
        fwd_mesh = 'fwd_mesh_l2';
    else
        fwd_mesh='fwd_mesh';
    end
recon_basis =[60 60];
mysave('diff_data',diff_data_matrix(:,i));
data_fn ='diff_data';
iteration =100;
output_fn = ['recon_dynamic_l1', num2str(recon_basis(1))];
filter_n =0;
lambda=1;
tim_1 = tic;
[fwd_mesh,pj_error] =reconstruct_dynamic_cw_L1(fwd_mesh,...
    recon_basis,...
    data_fn,...
    iteration,...
    lambda,...
    output_fn,...
    filter_n,...
    i)
   tim_total(i)=toc(tim_1);
 mean_tim_total=mean(tim_total)
figure,plotimage(fwd_mesh,fwd_mesh.mua);
% read_solution(fwd_mesh, output_fn);
save_mesh(fwd_mesh, 'fwd_mesh');

end

%------------------------------
%Average time
%total_reconstruction_time_l1=10.2306 secs
%l1_per_iteration_time=0.0073 sec
%total_reconstruction_time_l2=
%l2_per_iteratrion_time=
%-------------------------------
%%%%l-2 reconstruction%%%%
for i=1:10

    if i==1
    
        fwd_mesh = 'fwd_mesh_l2';
    else
        fwd_mesh='fwd_mesh';
    end
recon_basis =[60 60];
mysave('diff_data',diff_data_matrix(:,i));
data_fn ='diff_data';
iteration =100;
output_fn = ['recon_dynamic_l2', num2str(recon_basis(1))];
filter_n =0;
lambda=2;
tim_1 = tic;
[fwd_mesh,pj_error] = reconstruct_dynamic_cw_L1(fwd_mesh,...
    recon_basis,...
    data_fn,...
    iteration,...
    lambda,...
    output_fn,...
    filter_n,...
    i)
 tim_total(i)=toc(tim_1);
 mean_tim_total=mean(tim_total)
 figure,plotimage(fwd_mesh,fwd_mesh.mua);
% read_solution(fwd_mesh, output_fn);
save_mesh(fwd_mesh, 'fwd_mesh');

end
%%%%%%%%
%l2 
% lambda=15
% eps=1e-2

%%%ploting target image
for i=11:11
    mesh = load_mesh(mesh_name);
    
    blob.x =xcor(i);
    blob.y  =ycor(i);
    
    blob.r =10;
    blob.mua =0.02;
    blob.mus = 1.0;
    blob.ri = 1.33;
    blob.region = 1;
    
    
   meshb = add_blob_stnd(mesh, blob);
 
 figure,plotimage(meshb,meshb.mua);
% read_solution(fwd_mesh, output_fn);

end