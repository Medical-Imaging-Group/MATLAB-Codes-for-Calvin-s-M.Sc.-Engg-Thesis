%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%% Dynamic DOT with a stationary blob           %%%
%%%                                              %%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
close all;
clear all;

frames=8;%number of frames
mua=0.02;%initial mua
x=0;%specify the blob position
y=0;
mesh_name='circle_1933_86';%name of the mesh to be loaded
% mesh_name='504';
% mesh_name='1914_2';
% mesh_name='pat1915_1';
calib_mesh_name='circle_10249_86_16_2d';
% calib_mesh_name='1914';


mesh = load_mesh(calib_mesh_name);
blob.x =x;
blob.y  =y;
blob.r =10;
blob.mua =mua;
blob.mus = 1.0;
blob.ri = 1.33;
blob.region = 1;
meshb = add_blob_stnd(mesh, blob);
save_mesh(meshb, 'mesh_blob1');
plotimage(meshb,meshb.mua);
data_1 = femdata('mesh_blob1', 0);
mysave('mesh_blob1.paa', data_1.paa);

add_noise('mesh_blob1.paa',0, 0, 'mesh_blob1_Noise.paa') % 1% noise to the data


%calibration
[data1, mesh] = femdata(mesh,0);
save_data(data1,'mesh_data.paa');

homog_data = load_data('mesh_data.paa');
anom_data = load_data('mesh_blob1_Noise.paa'); %

mesh_homog = mesh_name;
mesh_anom  = mesh_name;

frequency = 0;
iteration = 5;


[data,mesh] = calibrate_stnd(homog_data,...
    anom_data,...
    mesh_homog,...
    mesh_anom,...
    frequency,...
    iteration);


save_data(data,'circle_stnd_calibrated_data.paa');
% save_mesh(mesh,'circle_stnd_calibrated');



%Reconstruction of first frame using non-linear method%
fwd_mesh =mesh;
tic;
recon_basis =[60 60];
data_fn_1 = 'circle_stnd_calibrated_data.paa';
iteration =20;
output_fn = ['recon_dynamic_l2', num2str(recon_basis(1))];
filter_n =0;
lambda=100;
[fwd_mesh,pj_error] = reconstruct_stnd_cw_first_frame(fwd_mesh,...
    recon_basis,...
    data_fn_1,...
    iteration,...
    lambda,...
    output_fn,...
    filter_n)
%  read_solution(fwd_mesh, output_fn);
figure,plotimage(fwd_mesh,fwd_mesh.mua)
save_mesh(fwd_mesh, 'fwd_mesh_l2');
toc;


for i=1:frames-1
    
    
    mesh = load_mesh(calib_mesh_name);
    blob.x =x;
    blob.y  =y;
    blob.r =10;
    blob.mua =mua;
    blob.mus = 1.0;
    blob.ri = 1.33;
    blob.region = 1;
    meshb = add_blob_stnd(mesh, blob);
    save_mesh(meshb, 'mesh1_blob1');
    data_1 = femdata('mesh1_blob1', 0);
    mysave('mesh1_blob1.paa', data_1.paa);
    
    add_noise('mesh1_blob1.paa',0, 0, 'mesh1_blob1_Noise.paa') % 1% noise to the data
    
    
    %calibration
    [data1, mesh] = femdata(mesh,0);
    save_data(data1,'mesh1_data.paa');
    
    homog_data = load_data('mesh1_data.paa');
    anom_data = load_data('mesh1_blob1_Noise.paa'); %
    
    mesh_homog = mesh_name;
    mesh_anom  = mesh_name;
    
    frequency = 0;
    iteration = 5;
    
    
    [data_1,mesh] = calibrate_stnd(homog_data,...
        anom_data,...
        mesh_homog,...
        mesh_anom,...
        frequency,...
        iteration);
    
    
    save_data(data_1,'mesh1_blob1_calibrated_data.paa');
    data_1_N=load_data('mesh1_blob1_calibrated_data.paa');
    data_1_N=data_1_N.paa;
    data_1_N=log(data_1_N(:,1));
    
    if i==1 |i==2 |i==3 |i==4
        mua=mua+0.005;%increase the mua value for the next frame
        
    elseif i==5 |i==6 |i==7 |i==8
        mua=mua-0.005;%decrease the mua value for the next frame
    end
    
    
    
    %%%Next frame%%%%
    mesh = load_mesh(calib_mesh_name);
    blob.x =x;
    blob.y  =y;
    blob.r =10;
    blob.mua =mua;
    blob.mus = 1.0;
    blob.ri = 1.33;
    blob.region = 1;
    meshb = add_blob_stnd(mesh, blob);
    save_mesh(meshb, 'mesh2_blob1');
    data_1 = femdata('mesh2_blob1', 0);
    mysave('mesh2_blob1.paa', data_1.paa);
    
    add_noise('mesh2_blob1.paa',0, 0, 'mesh2_blob1_Noise.paa') % 1% noise to the data
    
    
    %calibration
    [data1, mesh] = femdata(mesh,0);
    save_data(data1,'mesh2_data.paa');
    
    homog_data = load_data('mesh2_data.paa');
    anom_data = load_data('mesh2_blob1_Noise.paa'); %
    
    mesh_homog = mesh_name;
    mesh_anom  = mesh_name;
    
    frequency = 0;
    iteration = 5;
    
    
    [data_2,mesh] = calibrate_stnd(homog_data,...
        anom_data,...
        mesh_homog,...
        mesh_anom,...
        frequency,...
        iteration);
    
    
    save_data(data_2,'mesh2_blob1_calibrated_data.paa');
    data_2_N=load_data('mesh2_blob1_calibrated_data.paa');
    data_2_N=data_2_N.paa;
    data_2_N=log(data_2_N(:,1));
    diff_data_matrix(:,i)=data_2_N-data_1_N;
    
    
    close all;
end
save diff_data_matrix.mat diff_data_matrix
%%%%Reconstruction of frames %%%%%%%%%%%

%%%%l-1 reconstruction%%%%
load diff_data_matrix
for i=1:1
    tic;
    if i==1
        fwd_mesh = 'fwd_mesh_l2';
    else
        fwd_mesh='fwd_mesh';
    end
    recon_basis =[60 60];
    mysave('diff_data',diff_data_matrix(:,i));
    data_fn ='diff_data';
    iteration =100;
    output_fn = ['recon_dynamic_l1', num2str(recon_basis(1))];
    filter_n =0;
    lambda=1;
%     tim_1 = tic;
    [fwd_mesh,pj_error] = reconstruct_dynamic_cw_L1(fwd_mesh,...
        recon_basis,...
        data_fn,...
        iteration,...
        lambda,...
        output_fn,...
        filter_n,...
        i);
%      tim_total(i)=toc(tim_1);
%      mean_tim_total=mean(tim_total)
    %  if i==1
    %   figure;
    %  end
    %   subplot(1,frames-1,i)
    %   plotimage(fwd_mesh,fwd_mesh.mua);
    % read_solution(fwd_mesh, output_fn);
    figure,plotimage(fwd_mesh,fwd_mesh.mua);
    save_mesh(fwd_mesh, 'fwd_mesh');
    toc;
end

%%%For finding an optimum lambda%%%

   mesh = load_mesh(mesh_name);
    
    blob.x =0;
    blob.y  =0;
    
    blob.r =10;
    blob.mua =0.025;
    blob.mus = 1.0;
    blob.ri = 1.33;
    blob.region = 1;
    
    
    meshb = add_blob_stnd(mesh, blob);
    in_1=find(meshb.region ==1);
    rootmse=rmse(meshb.mua(in_1),fwd_mesh.mua(in_1));
    per_rmse=rootmse*100

%%%%%%
% %%%%profile plot
% input_mesh = 'circle_1933_86_blob2';
%
%
% mesh = load_mesh(input_mesh);
% max_ent = read_solution(mesh,'sol_fn');
% max_l2=read_solution(mesh,'sol_l2');
% format long;
% %x = linspace(-42.95,42.95,400);
% x = linspace(-40,40,400);
% %y = -(10/20).*x;
% y = x.*ones(1,length(x));
% %y = linspace(-20,20,400);
% z = y;
%
%
% % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % %
% xone = griddata(mesh.nodes(:,1),mesh.nodes(:,2),max_ent.mua,x,y);
% xorg = griddata(mesh.nodes(:,1),mesh.nodes(:,2),mesh.mua,x,y);
% xtwo = griddata(mesh.nodes(:,1),mesh.nodes(:,2),max_l2.mua,x,y);
%
% figure;
% hold on
% % subplot(1,3,1);
% hold on
% plot(x,xorg,'k-')
% plot(x,xone,'r--')
% plot(x,xtwo,'b--')
% legend('Target','CS','L2');
% % plot(x,xin,'k')
% % plot(x,xout,'k--')yyyyyyyyyyyyy
% hold off



%%%%l-2 reconstruction%%%%
for i=1:1
    tic;
    if i==1
        fwd_mesh = 'fwd_mesh_l2';
    else
        fwd_mesh='fwd_mesh';
    end
    recon_basis =[60 60];
    mysave('diff_data',diff_data_matrix(:,i));
    data_fn ='diff_data';
    iteration =1;
    output_fn = ['recon_dynamic_l2', num2str(recon_basis(1))];
    filter_n =0;
    lambda=30;
    [fwd_mesh,pj_error] = reconstruct_dynamic_cw_L2(fwd_mesh,...
        recon_basis,...
        data_fn,...
        iteration,...
        lambda,...
        output_fn,...
        filter_n,...
        i)
    %  if i==1
    %   figure;
    %  end
    %   subplot(1,frames-1,i)
    %   plotimage(fwd_mesh,fwd_mesh.mua);
    % read_solution(fwd_mesh, output_fn);
    figure,plotimage(fwd_mesh,fwd_mesh.mua);
    save_mesh(fwd_mesh, 'fwd_mesh');
    toc;
end

%%%For finding an optimum lambda%%%

  mesh = load_mesh(mesh_name);
    
    blob.x =0;
    blob.y  =0;
    
    blob.r =10;
    blob.mua =0.025;
    blob.mus = 1.0;
    blob.ri = 1.33;
    blob.region = 1;
    
    
    meshb = add_blob_stnd(mesh, blob);
    in_1=find(meshb.region ==1);
    in_2=find(fwd_mesh.region ==1)
    rootmse=rmse(meshb.mua(in_1),fwd_mesh.mua(in_1));
    per_rmse=rootmse*100
    

%%%%%%


%%%% Plot for optimum lambda%%%%
rms_l1=[0.545951325 0.5356921404 0.5313991 0.535687225 0.53983799 0.55130275 0.570326769 0.591 0.6];
lamb_l1=[1 25 50 75 100 150 200 300 500];
rms_l2=[0.64962101 0.6401 0.6382 0.63708 0.63500 0.63648 0.645 0.6552 0.65649771];
lamb_l2=[1 25 50 75 100 150 200 300 500];
hold on
xlabel('Regularization');
ylabel('RMS Error (%)');
plot(lamb_l2,rms_l2,'x-b','LineWidth',2,'MarkerSize',8);
plot(lamb_l1,rms_l1,'+-r','LineWidth',2,'MarkerSize',8);
legend('L1-based','L2-based');
%%%%%%

%%%Plot Target images

for i=1:frames
    mesh = load_mesh(mesh_name);
    
    blob.x =xcor(i);
    blob.y  =ycor(i);
    
    blob.r =10;
    blob.mua =mua;
    blob.mus = 1.0;
    blob.ri = 1.33;
    blob.region = 1;
    
    
    meshb = add_blob_stnd(mesh, blob);
    
    if i==1
        figure;
        %  title('Sparse reconstruction when the blob is moving(1% noise added)');
    end
    subplot(2,5,i-1)
    plotimage(meshb,meshb.mua);
    
end



%Contrast plot for 0 % noise
x=uint8(2:8);
y=[0.025 0.03 0.035 0.04 0.035 0.03 0.025];
y_l1=[0.0252 0.029 0.036 0.0393 0.0347 0.0282 0.024];
y_l2=[0.0253 0.0261099 0.0292 0.0312 0.0289 0.0261 0.0237];
subplot(2,2,1);
hold on
box on
title('Contrast plot for 0 % noise');
xlabel('frame');
ylabel('mean \mu_a of the target');
plot(x,y,'*-r','LineWidth',2,'MarkerSize',8);
plot(x,y_l1,'+-b','LineWidth',2,'MarkerSize',8);
plot(x,y_l2,'x-g','LineWidth',2,'MarkerSize',8);
legend('Target','L1','L2');


%Contrast plot for 1 % noise
x=uint8(2:8);
y=[0.025 0.03 0.035 0.04 0.035 0.03 0.025];
y_l1=[0.026 0.0306 0.0362 0.0388 0.0326 0.0287 0.024];
y_l2=[0.0253 0.0278 0.0299 0.0312 0.0293 0.0261 0.0238];
subplot(2,2,2);
hold on
box on
title('Contrast plot for 1 % noise');
xlabel('frame');
ylabel('mean \mu_a of the target');
plot(x,y,'*-r','LineWidth',2,'MarkerSize',8);
plot(x,y_l1,'+-b','LineWidth',2,'MarkerSize',8);
plot(x,y_l2,'x-g','LineWidth',2,'MarkerSize',8);
legend('Target','L1','L2');

%Contrast plot for 3 % noise
x=uint8(2:8);
y=[0.025 0.03 0.035 0.04 0.035 0.03 0.025];
y_l1=[0.0256 0.031 0.036 0.038 0.033 0.0277 0.0223];
y_l2=[0.0242 0.0268 0.0292 0.03 0.0282 0.0255 0.0226];
subplot(2,2,3);
hold on
box on
title('Contrast plot for 3 % noise');
xlabel('frame');
ylabel('mean \mu_a of the target');
plot(x,y,'*-r','LineWidth',2,'MarkerSize',8);
plot(x,y_l1,'+-b','LineWidth',2,'MarkerSize',8);
plot(x,y_l2,'x-g','LineWidth',2,'MarkerSize',8);
legend('Target','L1','L2');


%Contrast plot for 5 % noise
x=uint8(2:8);
y=[0.025 0.03 0.035 0.04 0.035 0.03 0.025];
y_l1=[0.0257 0.0301 0.0342 0.0366 0.0307 0.0269 0.0217];
y_l2=[0.0233 0.0264 0.0278 0.03 0.026 0.0236 0.0216];
subplot(2,2,4);
hold on
box on
title('Contrast plot for 5 % noise');
xlabel('frame');
ylabel('mean \mu_a of the target');
plot(x,y,'*-r','LineWidth',2,'MarkerSize',8);
plot(x,y_l1,'+-b','LineWidth',2,'MarkerSize',8);
plot(x,y_l2,'x-g','LineWidth',2,'MarkerSize',8);
legend('Target','L1','L2');
%%%mean values computation
in=find(fwd_mesh.mua>=0.022);
mean(fwd_mesh.mua(in));
