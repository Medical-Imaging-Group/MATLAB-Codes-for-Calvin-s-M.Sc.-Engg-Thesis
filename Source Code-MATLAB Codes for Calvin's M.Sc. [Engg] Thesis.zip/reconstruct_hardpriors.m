function [fwd_mesh,pj_error] = reconstruct_hardpriors(fwd_fn,frequency,data_fn,output_fn,lambda,iteration)

%HAMID reconstruction:
% reconstruct_region('circle2000_86','region[0 1 2]',100,'test.paa',100,10,'test',0)
% For perturbation approach:
% reconstruct_region('circle2000_86','circle2000_86',100,'test.paa',100,10,'test',0)

% Adopted from Hamid - reoncstruct_region.m
% Phaneendra Yalavarthy
% 11/25/2006

tic;

% load fine mesh for fwd solve
fwd_mesh = load_mesh(fwd_fn);



%
% if ischar(recon_basis)
%     if all(recon_basis(1:6) == 'region')
%         region=str2num(recon_basis(find(recon_basis=='[')+1:...
%             find(recon_basis==']')-1));
%         region = region_mapper(fwd_mesh,region);
%         if isempty(region)
%             disp('---------------------------------');
%             disp('Reconstruction basis not specified');
%             fprintf(fid_log,'---------------------------------\n');
%             return
%         end
%     else
%         recon_mesh = load_mesh(recon_basis);
%         [fwd_mesh.fine2coarse,...
%             recon_mesh.coarse2fine] = second_mesh_basis(fwd_mesh,recon_mesh);
%     end
% else
%     [fwd_mesh.fine2coarse,recon_mesh] = pixel_basis(recon_basis,fwd_mesh);
% end

% read data
anom = load(data_fn);
anom = log(anom(:,1));
% anom(:,2) = anom(:,2)/180.0*pi;
% anom(find(anom(:,2)<0),2) = anom(find(anom(:,2)<0),2) + (2*pi);
% anom(find(anom(:,2)>(2*pi)),2) = anom(find(anom(:,2)>(2*pi)),2) - (2*pi);
% anom = reshape(anom',length(anom)*2,1);

% Initiate projection error
pj_error = [];

% Initiate log file
fid_log = fopen([output_fn '.log'],'w');
fprintf(fid_log,'Forward Mesh   = %s\n',fwd_fn);
% if ischar(recon_basis)
%   fprintf(fid_log,'Basis          = %s\n',recon_basis);
% else
%   fprintf(fid_log,'Basis          = %s\n',num2str(recon_basis));
% end
fprintf(fid_log,'Frequency      = %f MHz\n',frequency);
fprintf(fid_log,'Data File      = %s\n',data_fn);
%fprintf(fid_log,'Initial Reg    = %d\n',lambda);
%fprintf(fid_log,'Filter         = %d\n',filter_n);
fprintf(fid_log,'Output Files   = %s_mua.sol\n',output_fn);
fprintf(fid_log,'               = %s_mus.sol\n',output_fn);

%if exist('region','var')==0
disp('Jacob region');
% Intializations
flag_mesh = 0;
regions = unique(fwd_mesh.region);
R = zeros(length(fwd_mesh.mua), length(regions));
KREC = zeros(length(regions),1);
MuaREC = KREC;

% store the region indices
for i = 1:length(regions)
    R1 = find(fwd_mesh.region == regions(i));
    RL(i) = length(R1);
    R(1:length(R1), i) = R1;
   % KREC(i) = mean(fwd_mesh.kappa(R1));
    MuaREC(i) = mean(fwd_mesh.mua(R1));
    clear R1;
end

for it = 1 : iteration

%mu =  [(KREC);(MuaREC)] ;

disp('calculating regions');
if ~exist('region','var')
    region = unique(fwd_mesh.region);
end
K = region_mapper(fwd_mesh,region);

  % Calculate jacobian
  [J,data]=jacobian(fwd_fn,frequency,fwd_mesh);    
%   [J,data] = jacobian_perturb_region(fwd_fn,frequency,fwd_mesh);
   J = J.complete;
   J = J*K;
          N2 = (fwd_mesh.mua'*K)./sum(K);
        nn = length(N2);
        
        for i = 1 : nn
            J(:,i) = J(:,i).*N2(i);
        end
  % reduce J into regions!

  
        %Read reference data
        clear ref;
        ref(:,1) = log(data.amplitude);
%         ref(:,2) = data.phase;
%         ref(:,2) = ref(:,2)/180.0*pi;
%         ref(find(ref(:,2)<0),2) = ref(find(ref(:,2)<0),2) + (2*pi);
%         ref(find(ref(:,2)>(2*pi)),2) = ref(find(ref(:,2)>(2*pi)),2) - (2*pi);
%         ref = reshape(ref',length(ref)*2,1);

        data_diff = (anom-ref);

        pj_error = [pj_error sum((anom-ref).^2)]

        disp('---------------------------------');
        disp(['Iteration Number          = ' num2str(it)]);
        disp(['Projection error          = ' num2str(pj_error(end))]);

        fprintf(fid_log,'---------------------------------\n');
        fprintf(fid_log,'Iteration Number          = %d\n',it);
        fprintf(fid_log,'Projection error          = %f\n',pj_error(end));

        if it ~= 1
            p = (pj_error(end-1)-pj_error(end))*100/pj_error(end-1);
            disp(['Projection error change   = ' num2str(p) '%']);
            fprintf(fid_log,'Projection error change   = %f %%\n',p);
            if ((p) <= 2)
                disp('---------------------------------');
                disp('STOPPING CRITERIA REACHED');
                fprintf(fid_log,'---------------------------------\n');
                fprintf(fid_log,'STOPPING CRITERIA REACHED\n');
                break
            end
        end
        
  N = J*((J'*J+lambda*eye(size(J,2)))\J');
  %N = (J*J')*((J*J'  + lambda*eye(size(J,1)))\eye(size(J,1)));
      [m n] = size(J);
    
        th = 0.9;
        th1 = 0;
        Dn = eye(m);        
        % % % % % % % % % % % % % % % % % % % % % % % % % % % %
        
        for i = 1:m
            
            if Dn(i,i) == 1
                x = N(:,i);
                in1 = find(x <=  th * max(x) | x == max(x));
                in2 = find(x > th * max(x) & x ~= max(x));
                Dn(in2, i) = 1;
                
                for iii = 1:length(in2)
                    Dn(in2(iii), in2(iii)) = 0;
                end
                Dn(i,i) = 1;
                clear in2 in1 x;
            end
        end
        
        in = find(diag(Dn) == 1);
        length_ind = length(in);
        
        
        %in = intersect(in,ind_diag);
        %length_new_ind = length(in);
        %dep = setdiff(1:m,in)';
        
        
        total_measurements = m;
        independent_measurements = length(in);
        
        per_independent = 100*length(in)/(m);

num_reg = unique(fwd_mesh.region);

diag_data = diag(N);

for i=1:length(in)
F(i) = N(in(i),in(i));
end

%   sorted_diag_data = (sort(F','descend'));

    sorted_diag_data = (sort(diag_data,'descend'));

for i=1:240
    ind_indices(i) = find(sorted_diag_data(i)==diag_data(:));
end

mu = MuaREC;
% if it==1
val = (ind_indices);%double(uint8(mod(rand(3,1)*240,240)));%Random Value
% end
% for ind_i = 1:length(val)
%     sour_ind(ind_i) = 0;
%     try_source = val(ind_i);
%     while try_source>0 
%         sour_ind(ind_i) = sour_ind(ind_i) +1;
%         try_source = try_source - 15;
%     end
% detector_ind(ind_i) = val(ind_i) - 15*(sour_ind(ind_i)-1);
% detector_ind(ind_i) = detector_ind(ind_i) + sour_ind(ind_i);
% if(detector_ind(ind_i)>16)
%     detector_ind(ind_i) = mod(detector_ind(ind_i),16);
%     if(detector_ind(ind_i)==0)
%         detector_ind(ind_i) = 16;
%     end
% end
% end
% i=1;
% j=1;
% jd = 1;
% te = 1:16;
% 
% while i<17
%     boll_val = find(te(i)==sour_ind);
%     if isempty(boll_val)
%         not_sour(j) = te(i);
%         j = j+ 1;
%     end
%     boll_val = find(te(i)==detector_ind);
%     if isempty(boll_val)
%         not_dete(jd) = te(i);
%         jd = jd+ 1;
%     end
%     i = i+1;
% end
%   figure;
%   ind = find(fwd_mesh.bndvtx==1);
%   if fwd_mesh.dimension == 2  
%     %plot(fwd_mesh.source(not_sour,1),fwd_mesh.source(not_sour,2),'k+','LineWidth',2,'MarkerSize',8);
%     plot(fwd_mesh.source(sour_ind,1),fwd_mesh.source(sour_ind,2),'ro','LineWidth',2,'MarkerSize',8); 
%     hold on;
%     %plot(fwd_mesh.meas(not_dete,1),fwd_mesh.meas(not_dete,2),'g^','LineWidth',2,'MarkerSize',8); 
%     plot(fwd_mesh.meas(detector_ind,1),fwd_mesh.meas(detector_ind,2),'bx','LineWidth',2,'MarkerSize',8);          
%     plot(fwd_mesh.nodes(ind,1),fwd_mesh.nodes(ind,2),'c.');
%     axis equal;
%     %legend('Source Not Used','Detector Not Used','Source','Detector');
%     legend('Source','Detector');
%   elseif mesh.dimension == 3
%     plot3(mesh.source(:,1),...
% 	  mesh.source(:,2),...
% 	  mesh.source(:,3),'ro',...
% 	  'LineWidth',2,'MarkerSize',8);
%     hold on;
%     plot3(mesh.meas(:,1),...
% 	  mesh.meas(:,2),...
% 	  mesh.meas(:,3),'bx',...
% 	  'LineWidth',2,'MarkerSize',8);
%     plot3(mesh.nodes(ind,1),...
% 	  mesh.nodes(ind,2),...
% 	  mesh.nodes(ind,3),'c.');
%     axis equal;
%     legend('Source','Detector');
%   end

%val = [238 239 240]; %End Values
%val = [1 2 3];%Beginning Values
new_anom = anom(val,:);

clear ind_indices

J = J(val,:);



%[foo] = fminsearch(@(mu) lsq_dot_region_cw_numreg_random(mu, fwd_mesh, new_anom,val),mu,optimset('MaxIter', 1000, 'TolX',1e-4));







%foo = lsqnonlin(@(mu) lsq_dot_region(mu, fwd_mesh, anom),mu)


% p = size(mu,1);
% 
% %funProj = @(x)boundProject(x,zeros(p,1),inf(p,1));
% 
% foo = minConf_PQN(@(mu) lsq_dot_region(fwd_mesh, anom, mu),mu,@(mu)boundProject(mu,zeros(p,1),inf(p,1)));


% K = linspace(0,10,50);
% A = linspace(0.01, 0.1, 50);
% gdvalues = {K A};
% 
% foo = simpgdsearch(@(mu) lsq_dot_region(mu, fwd_mesh, anom),gdvalues, [])

%[foo,pj_error,exitflag] = fminlbfgs(@(mu) lsq_dot_region(fwd_mesh, anom, mu),mu)

 %[foo,pj_error,exitflag] = fminunc(@(mu) lsq_dot_region(fwd_mesh, anom, mu),mu)
%mu = foo;

%mu(1:end/2) = (1./(3.*mu(1:end/2)))-mu(end/2+1:end);
%mu

%foo = differentialEvolution(@(mu) lsq_dot_region(fwd_mesh, anom, mu),mu*0.1,mu*10) 


%px=differentialEvolution(fitFunc,L,H,varargin)


 %[x,resnorm,residual,exitflag]

%[foo,pj_error,residual,exitflag] = lsqnonlin(@(mu) lsq_dot_region(fwd_mesh, anom, mu),mu)
%
%     Calculate jacobian
%         [data]=fwmdata(fwd_fn,frequency,fwd_mesh);
%
%         Read reference data
%         clear ref;
%         ref(:,1) = log(data.amplitude);
%         ref(:,2) = data.phase;
%         ref(:,2) = ref(:,2)/180.0*pi;
%         ref(find(ref(:,2)<0),2) = ref(find(ref(:,2)<0),2) + (2*pi);
%         ref(find(ref(:,2)>(2*pi)),2) = ref(find(ref(:,2)>(2*pi)),2) - (2*pi);
%         ref = reshape(ref',length(ref)*2,1);
%
%         data_diff = (anom-ref);
%
%         pj_error = [pj_error sum((anom-ref).^2)];
%
%         disp('---------------------------------');
%         disp(['Iteration Number          = ' num2str(it)]);
%         disp(['Projection error          = ' num2str(pj_error(end))]);
%
%         fprintf(fid_log,'---------------------------------\n');
%         fprintf(fid_log,'Iteration Number          = %d\n',it);
%         fprintf(fid_log,'Projection error          = %f\n',pj_error(end));
%
%         if it ~= 1
%             p = (pj_error(end-1)-pj_error(end))*100/pj_error(end-1);
%             disp(['Projection error change   = ' num2str(p) '%']);
%             fprintf(fid_log,'Projection error change   = %f %%\n',p);
%             if ((p) <= 1) & (exist('region','var')==0)
%                 disp('---------------------------------');
%                 disp('STOPPING CRITERIA REACHED');
%                 fprintf(fid_log,'---------------------------------\n');
%                 fprintf(fid_log,'STOPPING CRITERIA REACHED\n');
%                 break
%             elseif ((p) <= 0.5) & (exist('region','var')==1)
%                 disp('---------------------------------');
%                 disp('STOPPING CRITERIA REACHED');
%                 fprintf(fid_log,'---------------------------------\n');
%                 fprintf(fid_log,'STOPPING CRITERIA REACHED\n');
%                 break
%             end
%         end


% regular revonstruction
% Interpolate onto recon mesh
%[J,recon_mesh] = interpolatef2r(fwd_mesh,recon_mesh,J.complete);

%         % Normalize Jacobian wrt optical values
%         J = J*diag([(KREC);(MuaREC)]);
%
        % build hessian
        [nrow,ncol]=size(J);
        Hess = zeros(nrow);
        Hess = (J'*J);

%
%
        % Add regularization
        if it ~= 1
            lambda = lambda./10^0.25;
        end

        % Seems that scatter part is always more noisey. So we will make
        % sure that the regularization for phase is some factor (ratio
        % of amplitude vs phase diagonals of the Hessian) higher.
        % This 1st method not as objective as the second and implemented
        % method.
        %
        % reg = lambda*max(diag(Hess));
        % ph_factor = median(diag(Hess(1:2:end,1:2:end)) ./ ...
        %		       diag(Hess(2:2:end,2:2:end)));
        % reg = ones(nrow,1).*reg;
        % reg(1:2:end) =  reg(1:2:end).*ph_factor;
        % reg = diag(reg);

        reg_amp = lambda;%*max(diag(Hess));
        %reg_phs = lambda*max(diag(Hess(2:2:end,2:2:end)));
        reg = ones(ncol,1);
        reg(1:end) = reg(1:end).*reg_amp;
        %reg(2:2:end) = reg(2:2:end).*reg_phs;
        reg = diag(reg);

        disp(['Regularization        = ' num2str(reg(1,1))]);
        %disp(['Phs Regularization        = ' num2str(reg(2,2))]);
        fprintf(fid_log,'Regularization        = %f\n',reg(1,1));
        %fprintf(fid_log,'Phs Regularization        = %f\n',reg(2,2));
        Hess = Hess+reg;

        % Calculate update
        data_diff = anom(val,:) - ref(val,:);
%             data_diff = anom-ref;
        foo = (Hess\(J'*data_diff));
        % use region mapper to unregionize!
 
        foo = foo.*N2';
  clear nn N
 foo = K*foo;% K*foo(end/2+1:end)];
  
  
  % Update values
  fwd_mesh.mua = fwd_mesh.mua + (foo);
% Update values
% for i = 1:length(regions)
%     %fwd_mesh.kappa(R(1:RL(i),i)) =  (foo(i));
%     %KREC(i) =KREC(i) +(foo(i));
%     fwd_mesh.mua(R(1:RL(i),i)) = fwd_mesh.mua(R(1:RL(i),i)) + (foo(i));
%     % MuaREC(i) = MuaREC(i)+ (foo(end/2+i));
%     %fwd_mesh.mus(R(1:RL(i),i)) = (1./(3.*fwd_mesh.kappa(R(1:RL(i),i))))-fwd_mesh.mua(R(1:RL(i),i));
% end

clear foo Hess Hess_norm tmp data_diff G

% We dont like -ve mua or mus! so if this happens, terminate
%         if (any(fwd_mesh.mua<0) | any(fwd_mesh.mus<0))
%             disp('---------------------------------');
%             disp('-ve mua or mus calculated...not saving solution');
%             fprintf(fid_log,'---------------------------------\n');
%             fprintf(fid_log,'STOPPING CRITERIA REACHED\n');
%             break
%         end
%         % Filtering if needed!
%         if filter_n > 1
%             fwd_mesh = mean_filter(fwd_mesh,abs(filter_n));
%         elseif filter_n < 1
%             fwd_mesh = median_filter(fwd_mesh,abs(filter_n));
%         end
it = 1;
%if it == 1
    fid = fopen([output_fn '_mua.sol'],'w');
% else
%     fid = fopen([output_fn '_mua.sol'],'a');
% end
fprintf(fid,'solution %g ',it);
fprintf(fid,'-size=%g ',length(fwd_mesh.nodes));
fprintf(fid,'-components=1 ');
fprintf(fid,'-type=nodal\n');
fprintf(fid,'%f ',fwd_mesh.mua);
fprintf(fid,'\n');
fclose(fid);

%if it == 1
    fid = fopen([output_fn '_mus.sol'],'w');
%else
%    fid = fopen([output_fn '_mus.sol'],'a');
%end
fprintf(fid,'solution %g ',it);
fprintf(fid,'-size=%g ',length(fwd_mesh.nodes));
fprintf(fid,'-components=1 ');
fprintf(fid,'-type=nodal\n');
fprintf(fid,'%f ',fwd_mesh.mus);
fprintf(fid,'\n');
fclose(fid);

  end

% else % region basis reconstruction
%     disp('Jacob regular');
%     for it = 1 : iteration
%
%         % Calculate jacobian
%         [J,data]=jacobian(fwd_fn,frequency,fwd_mesh);
%
%         % Read reference data
%         clear ref;
%         ref(:,1) = log(data.amplitude);
%         ref(:,2) = data.phase;
%         ref(:,2) = ref(:,2)/180.0*pi;
%         ref(find(ref(:,2)<0),2) = ref(find(ref(:,2)<0),2) + (2*pi);
%         ref(find(ref(:,2)>(2*pi)),2) = ref(find(ref(:,2)>(2*pi)),2) - (2*pi);
%         ref = reshape(ref',length(ref)*2,1);
%
%         data_diff = (anom-ref);
%
%         pj_error = [pj_error sum((anom-ref).^2)];
%
%         disp('---------------------------------');
%         disp(['Iteration Number          = ' num2str(it)]);
%         disp(['Projection error          = ' num2str(pj_error(end))]);
%
%         fprintf(fid_log,'---------------------------------\n');
%         fprintf(fid_log,'Iteration Number          = %d\n',it);
%         fprintf(fid_log,'Projection error          = %f\n',pj_error(end));
%
%         if it ~= 1
%             p = (pj_error(end-1)-pj_error(end))*100/pj_error(end-1);
%             disp(['Projection error change   = ' num2str(p) '%']);
%             fprintf(fid_log,'Projection error change   = %f %%\n',p);
%             if ((p) <= 2) & (exist('region','var')==0)
%                 disp('---------------------------------');
%                 disp('STOPPING CRITERIA REACHED');
%                 fprintf(fid_log,'---------------------------------\n');
%                 fprintf(fid_log,'STOPPING CRITERIA REACHED\n');
%                 break
%             elseif ((p) <= 0.5) & (exist('region','var')==1)
%                 disp('---------------------------------');
%                 disp('STOPPING CRITERIA REACHED');
%                 fprintf(fid_log,'---------------------------------\n');
%                 fprintf(fid_log,'STOPPING CRITERIA REACHED\n');
%                 break
%             end
%         end
%         J = J.complete;
%
%         % reduce J into regions!
%         J = [J(:,1:end/2)*region J(:,end/2+1:end)*region];
%
%         % Normalisation factor
%         N = [(fwd_mesh.kappa'*region)./sum(region) ...
%             (fwd_mesh.mua'*region)./sum(region)];
%
%         % Normalise J
%         J = J*diag(N);
%
%         % build hessian
%         [nrow,ncol]=size(J);
%         Hess = zeros(ncol);
%         Hess = (J'*J);
%
%         % Add regularization
%         if it ~= 1
%             lambda = lambda./10^0.25;
%         end
%
%         reg_kap = lambda*max(diag(Hess(1:2:end,1:2:end)));
%         reg_mua = lambda*max(diag(Hess(2:2:end,2:2:end)));
%         reg = ones(ncol,1);
%         reg(1:end/2) = reg(1:end/2).*reg_kap;
%         reg(end/2+1:end) = reg(end/2+1:end).*reg_mua;
%         reg = diag(reg);
%
%         disp(['Kap Regularization        = ' num2str(reg(1))]);
%         disp(['mua Regularization        = ' num2str(reg(end))]);
%         fprintf(fid_log,'Kap Regularization        = %f\n',reg(1));
%         fprintf(fid_log,'mua Regularization        = %f\n',reg(end));
%         Hess = Hess+reg;
%
%         % Calculate update
%         foo = (Hess)\(J'*data_diff);
%         foo = foo.*N';
%
%         % use region mapper to unregionize!
%         foo = [region*foo(1:end/2); region*foo(end/2+1:end)];
%
%         % Update values
%         fwd_mesh.kappa = fwd_mesh.kappa + (foo(1:end/2));
%         fwd_mesh.mua = fwd_mesh.mua + (foo(end/2+1:end));
%         fwd_mesh.mus = (1./(3.*fwd_mesh.kappa))-fwd_mesh.mua;
%
%         clear foo Hess Hess_norm tmp data_diff G
%
%         % We dont like -ve mua or mus! so if this happens, terminate
%         if (any(fwd_mesh.mua<0) | any(fwd_mesh.mus<0))
%             disp('---------------------------------');
%             disp('-ve mua or mus calculated...not saving solution');
%             fprintf(fid_log,'---------------------------------\n');
%             fprintf(fid_log,'STOPPING CRITERIA REACHED\n');
%             break
%         end
%
%
%
%
%         % Filtering if needed!
%         if filter_n > 1
%             fwd_mesh = mean_filter(fwd_mesh,abs(filter_n));
%         elseif filter_n < 1
%             fwd_mesh = median_filter(fwd_mesh,abs(filter_n));
%         end
%
%         if it == 1
%             fid = fopen([output_fn '_mua.sol'],'w');
%         else
%             fid = fopen([output_fn '_mua.sol'],'a');
%         end
%         fprintf(fid,'solution %g ',it);
%         fprintf(fid,'-size=%g ',length(fwd_mesh.nodes));
%         fprintf(fid,'-components=1 ');
%         fprintf(fid,'-type=nodal\n');
%         fprintf(fid,'%f ',fwd_mesh.mua);
%         fprintf(fid,'\n');
%         fclose(fid);
%
%         if it == 1
%             fid = fopen([output_fn '_mus.sol'],'w');
%         else
%             fid = fopen([output_fn '_mus.sol'],'a');
%         end
%         fprintf(fid,'solution %g ',it);
%         fprintf(fid,'-size=%g ',length(fwd_mesh.nodes));
%         fprintf(fid,'-components=1 ');
%         fprintf(fid,'-type=nodal\n');
%         fprintf(fid,'%f ',fwd_mesh.mus);
%         fprintf(fid,'\n');
%         fclose(fid);
%
%     end
% end
%

% close log file!
time = toc;
fprintf(fid_log,'Computation Time = %f\n',time);
fclose(fid_log);





function [val_int,recon_mesh] = interpolatef2r(fwd_mesh,recon_mesh,val)

% This function interpolates fwd_mesh into recon_mesh
% For the Jacobian it is an integration!
NNC = size(recon_mesh.nodes,1);
NNF = size(fwd_mesh.nodes,1);
NROW = size(val,1);
val_int = zeros(NROW,NNC*2);

for i = 1 : NNF
    if recon_mesh.coarse2fine(i,1) ~= 0
        val_int(:,recon_mesh.elements(recon_mesh.coarse2fine(i,1),:)) = ...
            val_int(:,recon_mesh.elements(recon_mesh.coarse2fine(i,1),:)) + ...
            val(:,i)*recon_mesh.coarse2fine(i,2:end);
        val_int(:,recon_mesh.elements(recon_mesh.coarse2fine(i,1),:)+NNC) = ...
            val_int(:,recon_mesh.elements(recon_mesh.coarse2fine(i,1),:)+NNC) + ...
            val(:,i+NNF)*recon_mesh.coarse2fine(i,2:end);
    elseif recon_mesh.coarse2fine(i,1) == 0
        dist = distance(fwd_mesh.nodes,fwd_mesh.bndvtx,recon_mesh.nodes(i,:));
        mindist = find(dist==min(dist));
        mindist = mindist(1);
        val_int(:,i) = val(:,mindist);
        val_int(:,i+NNC) = val(:,mindist+NNF);
    end
end

for i = 1 : NNC
    if fwd_mesh.fine2coarse(i,1) ~= 0
        recon_mesh.mua(i,1) = (fwd_mesh.fine2coarse(i,2:end) * ...
            fwd_mesh.mua(fwd_mesh.elements(fwd_mesh.fine2coarse(i,1),:)));
        recon_mesh.mus(i,1) = (fwd_mesh.fine2coarse(i,2:end) * ...
            fwd_mesh.mus(fwd_mesh.elements(fwd_mesh.fine2coarse(i,1),:)));
        recon_mesh.kappa(i,1) = (fwd_mesh.fine2coarse(i,2:end) * ...
            fwd_mesh.kappa(fwd_mesh.elements(fwd_mesh.fine2coarse(i,1),:)));
        recon_mesh.region(i,1) = ...
            median(fwd_mesh.region(fwd_mesh.elements(fwd_mesh.fine2coarse(i,1),:)));
    elseif fwd_mesh.fine2coarse(i,1) == 0
        dist = distance(fwd_mesh.nodes,...
            fwd_mesh.bndvtx,...
            [recon_mesh.nodes(i,1:2) 0]);
        mindist = find(dist==min(dist));
        mindist = mindist(1);
        recon_mesh.mua(i,1) = fwd_mesh.mua(mindist);
        recon_mesh.mus(i,1) = fwd_mesh.mus(mindist);
        recon_mesh.kappa(i,1) = fwd_mesh.kappa(mindist);
        recon_mesh.region(i,1) = fwd_mesh.region(mindist);
    end
end

function [fwd_mesh,recon_mesh] = interpolatep2f(fwd_mesh,recon_mesh)


for i = 1 : length(fwd_mesh.nodes)
    fwd_mesh.mua(i,1) = ...
        (recon_mesh.coarse2fine(i,2:end) * ...
        recon_mesh.mua(recon_mesh.elements(recon_mesh.coarse2fine(i,1),:)));
    fwd_mesh.kappa(i,1) = ...
        (recon_mesh.coarse2fine(i,2:end) * ...
        recon_mesh.kappa(recon_mesh.elements(recon_mesh.coarse2fine(i,1),:)));
    fwd_mesh.mus(i,1) = ...
        (recon_mesh.coarse2fine(i,2:end) * ...
        recon_mesh.mus(recon_mesh.elements(recon_mesh.coarse2fine(i,1),:)));
end


function KKK=region_mapper(mesh,region)

% creates a matrix which is in effect a mapper to move
% between nodal basis or region basis.

nregion = length(region);
nnodes = length(mesh.nodes);

% create empty mapping matrix
K = sparse(nnodes,nregion);

% Assign mapping functions, for each node belonging to each region
for j = 1 : nregion
    K(find(mesh.region==region(j)),j) = 1;
end

% find the total number of assigned nodes
N = full(sum(sum(K)));

% Here if some node is not in region, must account for it
if N ~= length(mesh.nodes)
    KK = sparse(nnodes,nnodes-N);
    for k = 1 : length(region)
        if k == 1
            a = find(mesh.region~=region(k));
        else
            a = intersect(find(mesh.region~=region(k)),a);
        end
    end
    for i = 1 : length(a)
        KK(a(i),i) = 1;
    end
    KKK = [K KK];
else
    KKK = K;
end
