
% mesh = my_load_mesh('mesh_calib',1);
clear all;
close all;


anom_data = 'gel_785nm_plane0_rep0.paa';
mesh_exp = 'circle2000_86';


mesh_op = 'gelatin_NIR';
data_op = 'glatin_NIR_1.paa';
mesh_1=load_mesh('gelatin_NIR');
figure,plotimage(mesh_1,mesh_1.region);
gh_R=find(mesh_1.region==2);
mesh_1.region(gh_R)=1;
save_mesh(mesh_1,'gelatin_NIR_2R');
mesh_op='gelatin_NIR_2R';


mesh_1a=load_mesh('gelatin_NIR_2R');
 gh=find(mesh_1a.region==1);
 mesh_1a.mus(gh)=1;
% %mesh_1a.mus(gh_R)=1.2;
 mesh_1a.kappa = 1./(3.*(mesh_1a.mua + mesh_1a.mus));
mesh_op=mesh_1a;


mesh_2=load_mesh('gelatin_NIR_2R');
gh=find(mesh_2.region==0);
mesh_2.mua(gh)=0.0065;
gh=find(mesh_2.region==1);
mesh_2.mua(gh)=0.01;
figure,plotimage(mesh_2,mesh_2.mua);
save_mesh(mesh_2,'Prior_NIR_2R');


%%%%%%%%%%
%Hard Priors
tic;
% fwd_mesh=meshb;
       fwd_mesh ='circle2000_86_calibrated_mesh';
%      fwd_mesh =mesh_name;
recon_basis =[30 30];
data_fn = 'circle2000_86_calibrated_data.paa';
iteration =20;
output_fn = ['recon_dynamic_l2', num2str(recon_basis(1))];
filter_n =0;
lambda=20;
[fwd_mesh,pj_error] = reconstruct_hardpriors('gelatin_NIR_2R',0,data_op,output_fn,lambda,iteration)

 % read_solution(fwd_mesh, output_fn);
figure,plotimage(fwd_mesh,fwd_mesh.mua);
save_mesh(fwd_mesh, 'Hard_Prior');
toc;
%%%%%%%%%%

% % % % % % % % % % % % % % % % % % % % % 
%tic;
% fwd_mesh=meshb;
       fwd_mesh ='circle2000_86_calibrated_mesh';
%      fwd_mesh =mesh_name;
recon_basis =[30 30];
data_fn = 'circle2000_86_calibrated_data.paa';
iteration =20;
output_fn = ['recon_dynamic_l2', num2str(recon_basis(1))];
filter_n =0;
lambda=40;
[fwd_mesh,pj_error] = reconstruct_stnd_cw_spatial(mesh_op,...
                                                mesh_op,...
                                                data_op,...
                                                iteration,...
                                                lambda,...
                                                'Lap',...
                                                filter_n)

 % read_solution(fwd_mesh, output_fn);
figure,plotimage(fwd_mesh,fwd_mesh.mua);
save_mesh(fwd_mesh, 'Laplacian');
%toc;

%%%%For PIC-L1%%%%%%%%%
fwd_mesh ='circle2000_86_calibrated_mesh';
% tic;
recon_basis =[40 40];
data_fn_1 ='circle2000_86_calibrated_data.paa';
iteration =6;
output_fn = ['recon_dynamic_l2', num2str(recon_basis(1))];
filter_n =0;
lambda=50;
[fwd_mesh,pj_error] = reconstruct_stnd_cw_picL1(mesh_op,...
    mesh_op,...
    data_op,...
    iteration,...
    lambda,...
    'PIC',...
    filter_n,...
    fwd_mesh)
%  read_solution(fwd_mesh, output_fn);
figure,plotimage(fwd_mesh,fwd_mesh.mua)
save_mesh(fwd_mesh, 'PIC_L1');
% toc;
%%%%%%%%%
%%% Profile Plot%%%
mesh1=load_mesh('gelatin_NIR');
g=find(mesh1.region==0);
mesh1.mua(g)=0.0065;
g=find(mesh1.region==1);
mesh1.mua(g)=0.01;
g=find(mesh1.region==2);
mesh1.mua(g)=0.02;
figure,plotimage(mesh1,mesh1.mua);
 x = linspace(-41,41,40);
 y =16.*ones(1,length(x));
figure, plotimage(mesh1,mesh1.mua);
text(-32,8.5,'2','fontsize',42);
 text(-20,15,'1','fontsize',42);
 text(-43,8.5,'0','fontsize',42);
hold on;
 plot(x,y,'g-.');
 hold off
save_mesh(mesh1, 'Exp_target');
input_mesh = 'Exp_target';


mesh = load_mesh(input_mesh);
% max_ent = read_solution(mesh,'sol_piccs_fn');
max_l2=read_solution(mesh,'Lap');
max_l3=read_solution(mesh,'PIC');
format long;
%x = linspace(-42.95,42.95,400);
x = linspace(-42,42,400);
% y = -(10/20).*x;
 y = 18.*ones(1,length(x));
%y = linspace(-20,20,400);
z = y;
x1 = linspace(-42,42,100);
% y = -(10/20).*x;
 y1 = 18.*ones(1,length(x1));

% % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % 
% xone = griddata(mesh.nodes(:,1),mesh.nodes(:,2),max_ent.mua,x,y);
xorg = griddata(mesh.nodes(:,1),mesh.nodes(:,2),mesh.mua,x,y);
xtwo = griddata(mesh.nodes(:,1),mesh.nodes(:,2),max_l2.mua,x1,y1);
xthree = griddata(mesh.nodes(:,1),mesh.nodes(:,2),max_l3.mua,x,y);
figure;
hold on
% subplot(1,3,1);
hold on
plot(x,xorg,'k-')
% plot(x,xone,'r--')
plot(x1,xtwo,'b--')
plot(x,xthree,'g--')
legend('Target','Laplacian','PIC-L1');
% plot(x,xin,'k')
% plot(x,xout,'k--')yyyyyyyyyyyyy
hold off
%%%%%%%%%%%%%%%%%%%

