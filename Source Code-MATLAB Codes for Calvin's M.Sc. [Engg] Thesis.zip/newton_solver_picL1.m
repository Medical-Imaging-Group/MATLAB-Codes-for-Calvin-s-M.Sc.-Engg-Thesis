function [foo itt] = newton_solver_picL1(alpha,lambda,recon_mesh,J,data_diff,mu_pr,Lap)
%Quasi newton method
[~, ncol]=size(J);
% S=svd(J);
% Sm=max(S);
% SD=Sm*eye(ncol,ncol);
% J=J*SD;
%   Detailed explanation goes here

%     eps =0.0001;
 eps = 0.0001*norm(data_diff)    
err_pj = 20;
    foo =recon_mesh;
    r = J*foo - data_diff;
    rprev = r+2;
    th=1e-2;                                                                                                                                                                                 ;
    A=dct(eye(ncol,ncol));
    %Lap=A;
     n1=1/norm((A*mu_pr),1);
    n2=1/((J*mu_pr)'*(J*mu_pr));
    
%     grad = p*x.*(x.*conj(x)+params.l1Smooth).^(1/2-1);
    x=1*(A*foo);
    for i=1:length(x)
        x_s(i)=1/((x(i)*x(i)+th)^(1/2));
    end
    diag_mat=diag(x_s);
    del_mu_pr=foo-mu_pr;
    y=1*(Lap*(foo-mu_pr));
    for i=1:length(y)
        y_s(i)=1/((y(i)*y(i)+th)^(1/2));
    end
    diag_mat_pr=diag(y_s);
    itt=1;
    
    JTJ=J'*J;
     reg_mua = lambda*max(diag(JTJ));
    JTJ = JTJ + (Lap.*reg_mua);
%     S=svd(J);
%     Sm=max(S);
%     SD=1*Sm*eye(size(JTJ));
%     JTJ=JTJ+SD;

    JTD=J'*data_diff;
    
    
%while err_pj >eps
%   th = th./10^0.5;
        rn_p = norm(rprev,2);
        L=n1*(alpha*(Lap'*diag_mat_pr*Lap*del_mu_pr) + (1-alpha)*(A'*diag_mat*A*foo)) + n2*1*(lambda*JTJ*foo-lambda*JTD);
        Hess=n1*(alpha*(Lap'*diag_mat_pr*Lap) + (1-alpha)*(A'*diag_mat*A)) + n2*1*lambda*JTJ;
%         [~ ,foo_1]=RegualrizedMinResidualMtd(Hess,mu_pr,L,5);
         foo=foo-(Hess\L);
        rprev =r;
        r = J*foo - data_diff;
        rn = norm(r,2);
        x=1*(A*foo);
    for i=1:length(x)
        x_s(i)=1/((x(i)*x(i)+th)^(1/2));
    end
    diag_mat=diag(x_s);
    del_mu_pr=foo-mu_pr;
    y=1*(Lap*(foo-mu_pr));
    for i=1:length(y)
        y_s(i)=1/((y(i)*y(i)+th)^(1/2));
    end
    diag_mat_pr=diag(y_s);
        % diag_mat=diag_mat;
        err_pj = ((rn_p - rn));
        itt=itt+1;
 %end

    itt=itt-1;
end

