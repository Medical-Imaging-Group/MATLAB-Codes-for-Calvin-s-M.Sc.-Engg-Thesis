clear all;clc
% [J,data,mesh] = jacobian('mesh/2D_phantom',0);
% mesh.source.fwhm(:) = 3;
% [J,data,mesh] = jacobian(mesh,0);
% J = J.complete;
% save J J
% save mesh mesh

% load mesh
load mesh

% load Jacobian
load J

[nrow,ncol]=size(J);

% we have 350 frames of data, at a frame rate of 35Hz, therefore 10 seconds
% Using frame 1, as reference, reconstruct data from 2 -> 7 seconds
% i.e. frames 36:35:246 as in the Figure 13 of paper
% Daqing Piao et al, "Instrument for video-rate near-infrared diffuse
% optical tomography" Review of Scientific Instruments, 76 (2005)

% Need to calibrate data at t = 1 seconds
y_ref = load('processed/inject_ink_1.paa');
y_ref = y_ref(:,1);

% Calculate Hessian and inverse of regularized Hessian

% tic

% [U,S,V]=svd(J);
% diag_S = diag(S);
% clear S;
% UT = U.';
% clear U;
% SRc=[diag(diag_S) zeros(nrow,0);zeros(ncol-nrow,nrow) zeros(ncol-nrow,0)];
% 
% % reg_amp1 = max(diag(J*J')).*1e1 ;
% 
% lambda=10000;
% reg_amp = (lambda/10^0.25)/3.5;
% 
% diag_Sn = diag_S./ ((diag_S.^2) + (reg_amp));
% SRc(1:length(diag_Sn),1:length(diag_Sn)) = diag(diag_Sn);
% clear diag_Sn;
% update_eq=V*SRc*UT;
opts.basis.times = @(x)  dct(x);    % sparsfying basis
    opts.basis.trans = @(x) idct(x);    % inverse of basis
    opts.tol =1e-3;%(Stopping tolerance)
      opts.rho=1/20;
         opts.noneg=1;%(1 for non-negativity)
         opts.stepfreq=1;%exact steepest descesnt step length
%           opts.delta=0.0055;
%                opts.mu=1/20;%penalty parameter noise less case 1/30
         opts.nonorth=1;%(set to 1 if J is not orthonormailzed)
         opts.maxit=3;%(maximum iterations) noise less case 60
%               opts.nu=0.0000005;%>0 for L1/L1 model
first_frame=70;
eval(['y_anom1 = load(''processed/inject_ink_70.paa'');']);
    y_anom1 = y_anom1(:,1);
    y1 = log(y_anom1./y_ref);
   [foo_pf,Out] =yall1(J,y1,opts);%Your algorithm for l1 recovery(YALL1)
     Out
%     k = k+1;
opts.basis.times = @(x)  dct(x);    % sparsfying basis
    opts.basis.trans = @(x) idct(x);    % inverse of basis
    opts.tol =1e-3;%(Stopping tolerance)
%      opts.rho=1e-5;
         opts.noneg=1;%(1 for non-negativity)
         opts.stepfreq=1;%exact steepest descesnt step length
%           opts.delta=0.0055;
               opts.mu=1/25;%penalty parameter noise less case 1/30
         opts.nonorth=1;%(set to 1 if J is not orthonormailzed)
         opts.maxit=2;%(maximum iterations) noise less case 60
%               opts.nu=0.000000000005;%>0 for L1/L1 model
 k = 1;
for i = first_frame:4:111%36:35:246
    eval(['y_anom1 = load(''processed/inject_ink_' num2str(i) '.paa'');']);
      eval(['y_anom2 = load(''processed/inject_ink_' num2str(i+4) '.paa'');']);
    y_anom1 = y_anom1(:,1);
    y1 = log(y_anom1./y_ref);
        y_anom2 = y_anom2(:,1);
       y2 = log(y_anom2./y_ref);
     [foo,Out] =yall1(J,y2-y1,opts);%Your algorithm for l1 recovery(YALL1)
     Out
    mua(k,:) =foo_pf+foo;
    foo_pf=mua(k,:)';
    k = k+1;
    %     pdesurf(mesh.nodes(:,1:2)',mesh.elements',mua(1,:)')
end

% time = toc;
% disp(['Initialisation Time =' num2str(time)]);

minu = min(min(mua))
maxu = max(max(mua));

figure;
%  set(gca,'FontSize',28)
for i = 1:10
%     subplot(2,5,i);
    figure;
    trisurf(mesh.elements,...
        mesh.nodes(:,1),...
        mesh.nodes(:,2),...
        mesh.nodes(:,3),...
        mua(i,:));
    max_mua_l1(i) = max(mua(i,:))
    min(mua(i,:))
        save max_mua_l1.mat max_mua_l1;
    % we will threshold like as in paper.
%          caxis([minu maxu]);
       caxis([0 2]);
    shading interp; view(2);
    axis equal; axis off; colormap hot;
    %title('t = 0.85');
    colorbar ('horz');
end
% contrast plots
x=double([0 0.09 0.19 0.28 0.38 0.47 0.57 0.66 0.76 0.85]);
load max_mua_l1;
load max_mua_l2;
title('Contrast-ratio plot');
 hold on
 box on
plot(x,((1/0.01)*max_mua_l1),'*-r','LineWidth',2,'MarkerSize',8);
plot(x,((1/0.0003)*max_mua_l2),'+-b','LineWidth',2,'MarkerSize',8);
xlabel('time(sec)');
ylabel('recovered contrast ratio');
 legend('L1','L2');
